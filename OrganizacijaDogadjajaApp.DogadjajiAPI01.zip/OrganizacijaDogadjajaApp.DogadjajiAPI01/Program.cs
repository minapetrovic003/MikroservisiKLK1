using Microsoft.EntityFrameworkCore;
using OrganizacijaDogadjajaApp.DogadjajiAPI;
using OrganizacijaDogadjajaApp.DogadjajiAPI.Data;
using OrganizacijaDogadjajaApp.DogadjajiAPI.HostedServices;
using OrganizacijaDogadjajaApp.DogadjajiAPI.Services;
using OrganizacijaDogadjajaApp.DogadjajiAPI01.HostedServices;
using OrganizacijaDogadjajaApp.DogadjajiAPI01.Services;
using RabbitMQ.Client;

var builder = WebApplication.CreateBuilder(args);



// ========================================
// RABBIT MQ OPTIONS
// ========================================

builder.Services.Configure<RabbitMqOptions>(
    builder.Configuration.GetSection(RabbitMqOptions.SectionName));



// ========================================
// DB CONTEXT
// ========================================

builder.Services.AddDbContext<DogadjajiDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection")));



// ========================================
// CONTROLLERS + SWAGGER
// ========================================

builder.Services.AddControllers();

builder.Services.AddEndpointsApiExplorer();

builder.Services.AddSwaggerGen();



// ========================================
// POSTOJECI RABBIT MQ PUBLISHER
// ========================================

builder.Services.AddSingleton<IRabbitMqPublisher, RabbitMqPublisher>();



// ========================================
// NOVA RABBIT MQ CONNECTION
// ========================================

builder.Services.AddSingleton<IConnection>(sp =>
{
    var factory = new ConnectionFactory
    {
        HostName = "localhost"
    };

    return factory.CreateConnectionAsync().Result;
});



// ========================================
// POSTOJECI HOSTED SERVICES
// ========================================

builder.Services.AddHostedService<OutboxMessagePublisher>();

builder.Services.AddHostedService<DogadjajInfoResponderService>();



// ========================================
// SAGA SERVICES
// ========================================

builder.Services.AddScoped<ISagaPublisher, SagaPublisher>();

builder.Services.AddHostedService<SagaCompletionHostedService>();



var app = builder.Build();



// ========================================
// SWAGGER
// ========================================

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();

    app.UseSwaggerUI();
}



// ========================================
// MIDDLEWARE
// ========================================

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();



// ========================================
// START APP
// ========================================

app.Run();